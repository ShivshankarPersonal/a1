﻿namespace Module4.DomainModel.Persistence
{
    public enum MatchState
    {
        ToBePlayed = 0,
        InProgress = 1,
        Finished = 2
    }
}