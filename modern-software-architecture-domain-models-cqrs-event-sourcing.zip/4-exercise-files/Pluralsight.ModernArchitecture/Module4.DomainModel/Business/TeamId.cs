﻿namespace Module4.DomainModel.Business
{
    public enum TeamId
    {
        Unknown = 0,
        Home = 1,
        Visitors = 2
    }
}