﻿namespace Module4.DomainModel.DomainEvents
{
    public abstract class Message
    {
    }
}