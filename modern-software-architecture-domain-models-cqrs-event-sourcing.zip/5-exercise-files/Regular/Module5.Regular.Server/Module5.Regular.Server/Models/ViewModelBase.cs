﻿namespace Module5.Regular.Server.Models
{
    public class ViewModelBase
    {
        public ViewModelBase()
        {
            Title = "";
        }

        public string Title { get; set; } 
    }
}