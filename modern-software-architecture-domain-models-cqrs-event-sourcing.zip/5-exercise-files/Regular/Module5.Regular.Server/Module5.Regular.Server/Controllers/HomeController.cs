﻿using System.Web.Mvc;

namespace Module5.Regular.Server.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }
    }
}