﻿namespace Module5.Deluxe.QueryStack.DataAccess.Extensions 
{
    public static class CourtExtensions
    {
        //public static IQueryable<Court> All(this IQueryable<Court> courts)
        //{
            
        //}
    }
}