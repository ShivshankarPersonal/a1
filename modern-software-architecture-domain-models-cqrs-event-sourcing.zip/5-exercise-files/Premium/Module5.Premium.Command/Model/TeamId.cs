﻿namespace Module5.Premium.Command.Model
{
    public enum TeamId
    {
        Unknown = 0,
        Home = 1,
        Visitors = 2
    }
}