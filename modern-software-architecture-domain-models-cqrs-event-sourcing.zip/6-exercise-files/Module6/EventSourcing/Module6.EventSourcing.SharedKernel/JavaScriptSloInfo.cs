﻿namespace Module6.EventSourcing.SharedKernel
{
    public class JavaScriptSlotInfo
    {
        public string Action { get; set; }
        public string When { get; set; }
        public string CourtId { get; set; }
        public string StartingAt { get; set; }
        public string Name { get; set; }
        public string Length { get; set; }
    }
}