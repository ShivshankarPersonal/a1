﻿namespace Module6.EventSourcing.QueryStack.DataAccess.Extensions 
{
    public static class CourtExtensions
    {
        //public static IQueryable<Court> All(this IQueryable<Court> courts)
        //{
            
        //}
    }
}