(function() {
    'use strict';

    angular.module('app.csrf-attack', [
        'app.core',
        'app.widgets'
      ]);
})();
