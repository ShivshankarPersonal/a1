(function() {
    'use strict';

    angular.module('app.clickjacking-attack', [
        'app.core',
        'app.widgets'
      ]);
})();
