(function() {
    'use strict';

    angular.module('app.csrf', [
        'app.core',
        'app.widgets'
      ]);
})();
