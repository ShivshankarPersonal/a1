(function() {
    'use strict';

    angular.module('app.xss-search', [
        'app.core',
        'app.widgets'
      ]);
})();
