(function() {
    'use strict';

    angular.module('app.clickjacking', [
        'app.core',
        'app.widgets'
      ]);
})();
